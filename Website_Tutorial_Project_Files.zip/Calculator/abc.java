public class abc {
    public static void main(String[] args) {
        System.out.println("This is a Java program.");
    }
}
