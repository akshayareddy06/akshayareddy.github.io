function greet() {
    alert("Hello! You clicked the button.");
}
